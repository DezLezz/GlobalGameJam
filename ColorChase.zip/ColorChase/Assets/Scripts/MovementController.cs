using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovementController : MonoBehaviour
{

    public GameObject firstPersonPlayer;
    public GameObject mapPlayer;

    // Start is called before the first frame update
    void Start()
    {
        firstPersonPlayer.GetComponent<PlayerMovement>().enabled = true;
        mapPlayer.GetComponent<PlayerMovement2D>().enabled = false;

        if (firstPersonPlayer.GetComponent<CharacterController>().transform.position.x != mapPlayer.GetComponent<CharacterController>().transform.position.x + 200)
        {
            firstPersonPlayer.GetComponent<CharacterController>().Move(transform.TransformVector(new Vector3((mapPlayer.GetComponent<CharacterController>().transform.position.x + 200) - firstPersonPlayer.GetComponent<CharacterController>().transform.position.x, 0, 0)));
        }
        if (firstPersonPlayer.GetComponent<CharacterController>().transform.position.z != mapPlayer.GetComponent<CharacterController>().transform.position.z)
        {
            firstPersonPlayer.GetComponent<CharacterController>().Move(transform.TransformVector(new Vector3(0, 0, mapPlayer.GetComponent<CharacterController>().transform.position.z - firstPersonPlayer.GetComponent<CharacterController>().transform.position.z)));
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R))
        {
            firstPersonPlayer.GetComponent<PlayerMovement>().enabled = !firstPersonPlayer.GetComponent<PlayerMovement>().enabled;
            mapPlayer.GetComponent<PlayerMovement2D>().enabled = !mapPlayer.GetComponent<PlayerMovement2D>().enabled;

            if (firstPersonPlayer.GetComponent<CharacterController>().transform.position.x != mapPlayer.GetComponent<CharacterController>().transform.position.x +200)
            {
                firstPersonPlayer.GetComponent<CharacterController>().Move(transform.TransformVector(new Vector3((mapPlayer.GetComponent<CharacterController>().transform.position.x +200) - firstPersonPlayer.GetComponent<CharacterController>().transform.position.x,0,0)));
            }
            if (firstPersonPlayer.GetComponent<CharacterController>().transform.position.z != mapPlayer.GetComponent<CharacterController>().transform.position.z)
            {
                firstPersonPlayer.GetComponent<CharacterController>().Move(transform.TransformVector(new Vector3(0, 0, mapPlayer.GetComponent<CharacterController>().transform.position.z - firstPersonPlayer.GetComponent<CharacterController>().transform.position.z)));
            }

        }
    }
}
