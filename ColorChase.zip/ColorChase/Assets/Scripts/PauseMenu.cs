using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PauseMenu : MonoBehaviour
{
    public Button quit;
    public Button restart;
    public GameObject firstPP;
    public GameObject mapP;
    public GameObject firstPos;
    public GameObject mapPos;
    public bool EscapeMenuOpen = false;

    

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (EscapeMenuOpen == false)
            {
                quit.gameObject.SetActive(true);
                restart.gameObject.SetActive(true);
                EscapeMenuOpen = true;

                Cursor.visible = true;
                Cursor.lockState = CursorLockMode.Confined;

                firstPP.GetComponent<PlayerMovement>().enabled = false;
                mapP.GetComponent<PlayerMovement2D>().enabled = false;
            }
            else
            {
                quit.gameObject.SetActive(false);
                restart.gameObject.SetActive(false);
                EscapeMenuOpen = false;

                Cursor.visible = false;
                Cursor.lockState = CursorLockMode.Locked;

                firstPP.GetComponent<PlayerMovement>().enabled = true;
                mapP.GetComponent<PlayerMovement2D>().enabled = true;
            }
        }
    }

    public void Quit()
    {
        Application.Quit();
    }

    public void Restart()
    {
        SceneManager.LoadScene(1);
    }
}
