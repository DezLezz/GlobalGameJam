using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

public class changeScene : MonoBehaviour
{
    public Button start;
    public Button credits;
    public Button quit;
    public Button back;

    public TextMeshProUGUI gameName;
    public TextMeshProUGUI creditsText;

    public GameObject main;
    public GameObject credits_obj;

    public Sound sound;

    public void Start()
    {
       sound.SoundIsPlaying();
    }
    public void ButtonStart()
    {

        SceneManager.LoadScene(1);
    }

    public void Quit()
    {
        Application.Quit();
    }

    public void Credits()
    {
        main.SetActive(false);
        credits_obj.SetActive(true);
    }

    public void Back()
    {
        main.SetActive(true);
        credits_obj.SetActive(false);
    }
}
